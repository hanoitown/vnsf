﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class OrderLine
    {
        public static OrderLine Create(Product product, int quantity, Order order)
        {
            return new OrderLine()
            {
                Product = product,
                Quantity = quantity,
                Order = order,
                Price = product.GetLastestPrice(order.Date).Calculate()
            };
        }

        public Product Product { get; set; }
        public int Quantity { get; set; }
        public Order Order { get; set; }
        public int Price { get; set; }

    }
}
