﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class Address
    {
        public Address(string po, string zip)
        {
            PO = po;
            Zip = zip;
        }

        public string PO { set; get; }
        public string Zip { get; set; }

    }
}
