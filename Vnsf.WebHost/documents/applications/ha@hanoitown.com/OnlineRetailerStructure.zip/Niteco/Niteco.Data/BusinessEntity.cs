﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class BusinessEntity : IProvider, IConsumer
    {
        public string Name { get; set; }
        public Address VisitingAddress { set; get; }
        public Address InvoiceAddress { set; get; }

        public BusinessEntity()
        {
        }

        public virtual void ShowInfo() { }

        public void PlaceOrder(Store store, Order order)
        {
            store.Orders.Add(order);

            foreach (var item in order.LineItems)
            {
                var inventoryItem = store.Inventories.Find(i => i.Product.SKU == item.Product.SKU);
                inventoryItem.QuantityOnHand -= item.Quantity;
            }
        }


        //Since we do not have order processor, actor will have to process the order
        public void Supply(Store store, Order order)
        {
            store.Orders.Add(order);

            foreach (var item in order.LineItems)
            {
                var inventoryItem = new ProductInventory()
                    {
                        Product = item.Product
                    };

                inventoryItem.QuantityOnHand = item.Quantity;
                var supplier = store.Suppliers.First(s => s.Supplier.Name == Name);
                inventoryItem.TotalValue = item.Quantity * supplier.Price;

                var result = store.Inventories.FirstOrDefault(i => i.Product.SKU == item.Product.SKU);
                if (result != null)
                {
                    result.QuantityOnHand += inventoryItem.QuantityOnHand;
                    result.TotalValue += inventoryItem.TotalValue;
                }
                else
                    store.Inventories.Add(inventoryItem);

            }

        }

    }
}
