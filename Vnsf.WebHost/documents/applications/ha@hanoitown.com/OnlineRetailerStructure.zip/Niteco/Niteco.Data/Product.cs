﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class Product
    {
        public string SKU { get; set; }
        public List<SellingPrice> UnitPrices { get; set; }
        public List<ProductSupplier> Suppliers { set; get; }

        public Product()
        {
            UnitPrices = new List<SellingPrice>();
        }


        public SellingPrice GetLastestPrice(DateTime dateTime)
        {
            foreach (var price in UnitPrices)
            {
                if (price.StartDate <= dateTime)
                    return new CampaignPrice(dateTime);
            }

            return new StandardPrice(dateTime);
        }
    }
}
