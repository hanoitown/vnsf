﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class Store
    {
        public string Name { get; set; }
        public List<ProductInventory> Inventories { set; get; }
        public List<Order> Orders { get; set; }
        public List<ProductSupplier> Suppliers { set; get; }

        public Store()
        {
        }
        public Store(string name)
        {
            Name = name;
            Suppliers = new List<ProductSupplier>();
            Orders = new List<Order>();
            Inventories = new List<ProductInventory>();
        }


        public void AddSupplier(BusinessEntity business, Product product, int sellingPrice, bool isPrimary)
        {
            var supplier = new ProductSupplier()
            {
                Supplier = business,
                Product = product,
                Price = sellingPrice,
            };

            Suppliers.Add(supplier);
        }

        public void ShowStatus()
        {
            Console.WriteLine(string.Format("{0} has servered {1} orders", Name, Orders.Count));
            Console.WriteLine("-------------");
            foreach (var item in Inventories)
            {
                Console.WriteLine(string.Format("SKU:{0} - #{1} - ${2}", item.Product.SKU, item.QuantityOnHand, item.TotalValue));
            }
            Console.ReadLine();

        }
    }
}
