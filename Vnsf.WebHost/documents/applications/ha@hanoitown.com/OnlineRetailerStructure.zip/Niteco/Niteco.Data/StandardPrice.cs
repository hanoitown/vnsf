﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class StandardPrice : SellingPrice
    {
        public StandardPrice(DateTime startdate)
            : base(startdate)
        {

        }
        public override int Calculate()
        {
            return 5;
        }
    }
}
