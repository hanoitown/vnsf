﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public interface IConsumer
    {
        void PlaceOrder(Store store, Order order);
    }
}
