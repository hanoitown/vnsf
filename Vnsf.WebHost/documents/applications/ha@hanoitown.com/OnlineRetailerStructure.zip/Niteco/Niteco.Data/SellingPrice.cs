﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public abstract class SellingPrice
    {
        public string Name { get; set; }
        public Product Product { set; get; }
        public DateTime StartDate { get; set; }
        public int Price { get; set; }

        public SellingPrice(DateTime startdate)
        {
            StartDate = startdate;
        }


        public virtual int Calculate() { return Price; }
    }
}
