﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class Person : BusinessEntity
    {
        public string IdcardNo { get; set; }

        public override void ShowInfo()
        {
            Console.WriteLine(string.Format("Personal info: {0}-{1}", this.IdcardNo, Name));
        }


    }
}
