﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class Order
    {
        public static Order Create(DateTime date)
        {
            return new Order()
            {
                OrderId = Guid.NewGuid(),
                Date = DateTime.Now,
                LineItems = new List<OrderLine>()
            };
        }
        public Guid OrderId { get; set; }
        public DateTime Date { get; set; }
        public List<OrderLine> LineItems { get; set; }
        public BusinessEntity Customer { set; get; }


    }
}
