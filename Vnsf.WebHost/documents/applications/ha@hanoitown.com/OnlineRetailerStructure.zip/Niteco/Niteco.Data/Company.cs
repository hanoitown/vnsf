﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class Company : BusinessEntity
    {
        public string RegistrationNo { get; set; }

        public override void ShowInfo()
        {
            Console.WriteLine(string.Format("Company info: {0}-{1}", this.RegistrationNo, this.Name));
        }

    }
}
