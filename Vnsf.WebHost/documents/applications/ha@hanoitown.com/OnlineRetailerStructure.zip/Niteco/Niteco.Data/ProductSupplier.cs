﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class ProductSupplier
    {
        public Product Product { get; set; }
        public BusinessEntity Supplier { get; set; }
        public bool isPrimary { get; set; }
        public int Price { set; get; }
    }
}
