﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Niteco.Data
{
    public class ProductInventory
    {
        public Product Product { get; set; }
        public int QuantityOnHand { get; set; }
        public int TotalValue { get; set; }
    }
}
