﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Niteco.Data;

namespace Niteco
{
    class Program
    {
        /// <summary>
        /// Store will server order for import and sell product, each order several Line
        /// Both person and company could buy (IConsumer) and sell(IProvider) product in the store
        /// they share the common information which are encapsulated in base class (BusinessEntity)
        /// 
        /// Buy order:  price is determined based on the datetime of the order
        /// Sell order: price will be determined when business entity (person/company) register as 
        ///             a supplier for a specific product in the store
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            var niteco = new Store("Niteco");

            var jonh = new Person()
            {
                Name = "john",
                IdcardNo = "ABC123"
            };
            jonh.VisitingAddress = jonh.InvoiceAddress = new Address("123", "ABC");


            var erricson = new Company()
            {
                Name = "erricson",
                RegistrationNo = "XYZ789"
            };
            erricson.VisitingAddress = erricson.InvoiceAddress = new Address("789", "XYZ");

            var orange = new Product()
            {
                SKU = "orange",
                UnitPrices = new List<SellingPrice>()
                {
                    new StandardPrice(DateTime.Now),
                    new CampaignPrice(DateTime.Now.AddDays(6))
                }
            };
            var apple = new Product()
            {
                SKU = "apple",
                UnitPrices = new List<SellingPrice>()
                {
                    new StandardPrice(DateTime.Now),
                    new CampaignPrice(DateTime.Now.AddDays(5))
                }
            };


            //register products supplier
            niteco.AddSupplier(jonh, apple, 2, true);
            niteco.AddSupplier(erricson, apple, 3, false);

            niteco.AddSupplier(jonh, orange, 1, false);
            niteco.AddSupplier(erricson, orange, 2, true);

            //person be a supplier
            var individualSOrder = Order.Create(DateTime.Now);
            individualSOrder.LineItems = new List<OrderLine>()
            {
                new OrderLine(){Product = orange, Quantity=4}
            };
            jonh.Supply(niteco, individualSOrder);


            var coperateSOrder = Order.Create(DateTime.Now);
            coperateSOrder.LineItems = new List<OrderLine>()
            {
                new OrderLine(){Product = apple, Quantity=6}
            };
            erricson.Supply(niteco, coperateSOrder);


            var individualBOrder = Order.Create(DateTime.Now.AddDays(6));
            individualBOrder.LineItems = new List<OrderLine>(){
                new OrderLine(){Product = apple, Quantity=2}
            };
            jonh.PlaceOrder(niteco, individualBOrder);

            //company as a customer
            var coperateBOrder = Order.Create(DateTime.Now.AddDays(6));
            coperateBOrder.LineItems = new List<OrderLine>(){
                new OrderLine(){Product = orange, Quantity=2}
            };
            erricson.PlaceOrder(niteco, individualBOrder);

            //show store information
            niteco.ShowStatus();
        }
    }

}
